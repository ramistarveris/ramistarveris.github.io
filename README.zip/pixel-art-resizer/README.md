# Pixel Art Resizer

Static browser-based pixel-art resizer for GitHub Pages.

## URL

`https://ramistarveris.github.io/pixel-art-resizer/`

## Features

- Drag and drop multiple images
- Nearest-neighbor scaling
- x1 to x100 presets
- Per-image or batch scale selection
- PNG download
- All processing stays in the browser
- No server or Node.js required

## GitHub Pages

Copy this folder to:

`E:\Projects\ramistarveris.github.io\pixel-art-resizer`

Then commit and push the `ramistarveris.github.io` repository.
